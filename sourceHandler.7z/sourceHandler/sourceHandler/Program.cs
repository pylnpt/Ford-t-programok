﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace sourceHandler
{
    class Program
    {
        static void Main(string[] args)
        {
           // SourceHandler sh = new SourceHandler(@"C:\Users\user\Desktop\Text.txt");
            //sh.openFile();
            //sh.replaceContent();
            //sh.openWrite(sh.Path);
            
            /*
             * string patternnumber = @"([0-9]+)";
            string patternVAR = @"([a-z-_]+)";

            string replacementNumber = " CONST[$1] ";
            string replacementVAR = " VAR[$1] ";
            string input = "IF (a==2) {b=6}";
            Console.WriteLine("The original input is: \n\n{0}\n", input);

            string result = Regex.Replace(input, patternnumber, replacementNumber);
            result = Regex.Replace(result, patternVAR, replacementVAR);
            Console.WriteLine("The result is :\n\n{0}\n",result);
             */


            //string content = "if(A === sh) + [key => value]\t{}}{{}while(true) + ";


            SourceHandler sh = new SourceHandler(@"C:\Users\user\Desktop\Text.txt");
            sh.openFile();
            sh.lexer();
            sh.openWrite(sh.Path);


            Console.ReadKey();
        }
    }
}
