﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace sourceHandler
{
    class SourceHandler
    {
        string path = "";
        string sourceCode = "";
        string content = "";

        Dictionary<string, string> replaces = new Dictionary<string, string>
        {
            {"\n", " "},
            {"\t", " "},
            {"{ ", "{"},
            {"} ", "}"},
            {" {", "{"},
            {" }", "}"},
            {"  ", " "}
        };

        List<string> SymbolTable = new List<string>();
        int SymbolTableIndex = 0;

        string findAndReplaceContent(string VariableOrConstant)
        {
            string res = "";
            if (SymbolTable.Contains(VariableOrConstant))
            {
                SymbolTable.Add(VariableOrConstant);
                SymbolTableIndex++;
                res = "00" + SymbolTableIndex.ToString();
            }
            else
            {
                res = "00" + VariableOrConstant.IndexOf(SymbolTable,0,VariableOrConstant.Length, VariableOrConstant);
            }
            
            return res.Substring(res.Length - 3);
        }

        public void lexer()
        {
            string patternNumber = @"([0-9])";
            string patternVAR = @"([a-z-_]+)";
            content = Regex.Replace(content, patternVAR, adat => findAndReplaceContent(adat.Groups[1].Value));

            content = Regex.Replace(content, patternNumber, adat2 =>  findAndReplaceContent(adat2.Groups[1].Value));
            Console.WriteLine(content);
        }

        //Konstruktor(DONE), property(getter, setter) a pathnek(DONE) two functions(openFile, openWrite) (DONE)
 
        //Constructors
        public SourceHandler(){}
        public SourceHandler(string path) {
            this.path = path;
        }

        //public SourceHandler(string text)
        //{
          //  this.content = text;
          //  replaceContent();
          //  Console.WriteLine(content);
        //}

        //Property
        public string Path
        {
            get { return this.path; }
            set { this.path = value; }
        }

        //Functions
        public void openFile()
        {
            try
            {
                StreamReader Sr = new StreamReader(File.OpenRead(path));
                sourceCode = Sr.ReadToEnd();
                content = sourceCode;
                Sr.Close();
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine("An Error has occured: {0}", e);
                throw;
            }
        }
        public void openWrite(string a)
        {
            try
            {
                StreamWriter Swr = new StreamWriter(File.Open(a, FileMode.Create));
                Swr.WriteLine(this.content);
                Swr.Flush();
                Swr.Close();
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine("An Error has occured: {0}", e.Message);
                throw;
            } 
        }
        public void replaceContent()
        {
            var lineComments = @"//.*?\n";
            var blockComments = @"/[*] [\w\d\s]+[*]/";
            content = Regex.Replace(content, blockComments, " ");
            content = Regex.Replace(content, lineComments, " ");

            foreach (var x in replaces)
            {
                while (content.Contains(x.Key))
                {
                    content = content.Replace(x.Key, x.Value);
                }
            }
            
        }
    }
}